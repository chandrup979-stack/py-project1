from flask import Flask, render_template, request
import pickle

app = Flask(__name__)

# Load trained model
model = pickle.load(
    open("model/fake_news_model.pkl", "rb")
)

# Load vectorizer
vectorizer = pickle.load(
    open("model/vectorizer.pkl", "rb")
)

@app.route("/", methods=["GET", "POST"])
def home():

    prediction = ""

    if request.method == "POST":

        news = request.form["news"]

        # Convert text into numbers
        vector = vectorizer.transform([news])

        # Predict
        result = model.predict(vector)

        if result[0] == 0:
            prediction = "FAKE NEWS"
        else:
            prediction = "REAL NEWS"

    return render_template(
        "index.html",
        prediction=prediction
    )

if __name__ == "__main__":
    app.run(debug=True)