import pandas as pd
import re
import pickle

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.metrics import accuracy_score

# Load datasets
fake = pd.read_csv("dataset/fake.csv")
true = pd.read_csv("dataset/true.csv")

# Add labels
fake["label"] = 0
true["label"] = 1

# Combine datasets
data = pd.concat([fake, true])

# Clean text function
def clean_text(text):

    text = str(text)

    text = text.lower()

    text = re.sub(r'http\S+', '', text)

    text = re.sub(r'[^a-zA-Z ]', '', text)

    return text

# Apply cleaning
data["text"] = data["text"].apply(clean_text)

# Input and output
X = data["text"]

y = data["label"]

# Convert text into numbers
vectorizer = TfidfVectorizer()

X = vectorizer.fit_transform(X)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Create model
model = PassiveAggressiveClassifier(
    max_iter=50,
    loss="hinge",
    random_state=42
)

# Train model
model.fit(X_train, y_train)

# Prediction
y_pred = model.predict(X_test)

# Accuracy
score = accuracy_score(y_test, y_pred)

print("Accuracy :", score)

# Save model
pickle.dump(
    model,
    open("model/fake_news_model.pkl", "wb")
)

# Save vectorizer
pickle.dump(
    vectorizer,
    open("model/vectorizer.pkl", "wb")
)

print("Model Saved Successfully")